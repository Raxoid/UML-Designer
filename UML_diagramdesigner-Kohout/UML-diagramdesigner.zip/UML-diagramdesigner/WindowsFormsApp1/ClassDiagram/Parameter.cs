﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1.ClassDiagram
{
    public class Parameter
    {
        public string MethodName { get; set; }
        public string Name { get; set; }

        public string DataType { get; set; }

    }
}
